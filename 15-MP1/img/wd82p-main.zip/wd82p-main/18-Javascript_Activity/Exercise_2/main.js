// Create three variables 'testScore1', 'testScore2', and 'testScore3' and assign them different test scores as numbers.
// Calculate the average test score of these three scores and store it in a variable called 'averageScore'.
// Round the 'averageScore' to the nearest integer using Math.round().

// Your code here

// Log the 'averageScore' to the console.

testscore1 = 75;
testscore2 = 80;
testscore3 = 85;

let averageScore = ((testscore1 + testscore2 + testscore3) / 3) * 100;

console.log(averageScore);
